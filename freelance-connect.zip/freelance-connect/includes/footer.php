<footer>
    <p>&copy; 2025 Freelance Connect. All Rights Reserved.</p>
</footer>
</body>
</html>
