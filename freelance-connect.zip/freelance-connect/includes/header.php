<?php 
session_start(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Freelance Connect</title>
    <link rel="stylesheet" href="../assets/css/style.css"> <!-- Adjust this based on file structure -->
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="../pages/browse_jobs.php">Browse Jobs</a></li>
                <li><a href="../pages/post_job.php">Post a Job</a></li>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li><a href="../pages/dashboard.php">Dashboard</a></li>
                    <li><a href="../process/logout.php">Logout</a></li>
                <?php else: ?>
                    <li><a href="../pages/login.php">Login</a></li>
                    <li><a href="../pages/register.php">Register</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>
                </body>
                </html>
