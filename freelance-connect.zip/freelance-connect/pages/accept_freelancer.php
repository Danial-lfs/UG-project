<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include("../includes/db_connect.php");

if (!isset($_GET['application_id'])) {
    echo "Invalid application.";
    exit();
}

$application_id = $_GET['application_id'];

// Get job details
$query = "SELECT applications.*, jobs.client_id 
          FROM applications 
          JOIN jobs ON applications.job_id = jobs.id 
          WHERE applications.id = $application_id";

$result = $conn->query($query);
$application = $result->fetch_assoc();

if ($application['client_id'] != $_SESSION['user_id']) {
    echo "Unauthorized action.";
    exit();
}

// Accept the freelancer
$update_query = "UPDATE applications SET status = 'accepted' WHERE id = $application_id";
if ($conn->query($update_query) === TRUE) {
    header("Location: dashboard.php");
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
