<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include("../includes/header.php");
include("../includes/db_connect.php");

if (!isset($_GET['job_id'])) {
    echo "Invalid job ID.";
    exit();
}

$job_id = $_GET['job_id'];
$query = "SELECT title FROM jobs WHERE id = $job_id";
$result = $conn->query($query);

if ($result->num_rows == 0) {
    echo "Job not found.";
    exit();
}

$job = $result->fetch_assoc();
?>

<div class="container">
    <h2>Apply for: <?php echo $job['title']; ?></h2>
    <form action="../process/apply_job_process.php" method="post">
        <input type="hidden" name="job_id" value="<?php echo $job_id; ?>">
        <textarea name="proposal" placeholder="Write your proposal..." required></textarea>
        <input type="text" name="bid_amount" placeholder="Your Bid Amount (USD)" required>
        <button type="submit">Submit Application</button>
    </form>
</div>

<?php include("../includes/footer.php"); ?>
