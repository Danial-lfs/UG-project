<?php
include("../includes/header.php");
include("../includes/db_connect.php");

// Fetch job categories for the filter dropdown
$categoryQuery = "SELECT DISTINCT category FROM jobs";
$categoryResult = $conn->query($categoryQuery);

// Search and Filter Logic
$search = isset($_GET['search']) ? trim($_GET['search']) : "";
$category = isset($_GET['category']) ? $_GET['category'] : "";
$job_type = isset($_GET['job_type']) ? $_GET['job_type'] : "";

// Build SQL query with optional filters
$query = "SELECT jobs.*, users.name AS client_name 
          FROM jobs 
          JOIN users ON jobs.client_id = users.id 
          WHERE 1=1";

if (!empty($search)) {
    $query .= " AND (jobs.title LIKE '%$search%' OR jobs.description LIKE '%$search%')";
}

if (!empty($category)) {
    $query .= " AND jobs.category = '$category'";
}

if (!empty($job_type)) {
    $query .= " AND jobs.job_type = '$job_type'";
}

$query .= " ORDER BY jobs.created_at DESC";
$result = $conn->query($query);
?>

<div class="container">
    <h2>Browse Available Jobs</h2>

    <!-- Job Search and Filter Section -->
    <section class="job-filters">
        <form method="GET" action="">
            <input type="text" name="search" placeholder="Search for jobs..." value="<?php echo htmlspecialchars($search); ?>">
            
            <select name="category">
                <option value="">All Categories</option>
                <?php while ($row = $categoryResult->fetch_assoc()): ?>
                    <option value="<?php echo $row['category']; ?>" <?php echo ($row['category'] == $category) ? 'selected' : ''; ?>>
                        <?php echo ucfirst($row['category']); ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <select name="job_type">
                <option value="">All Job Types</option>
                <option value="Full-Time" <?php echo ($job_type == 'Full-Time') ? 'selected' : ''; ?>>Full-Time</option>
                <option value="Part-Time" <?php echo ($job_type == 'Part-Time') ? 'selected' : ''; ?>>Part-Time</option>
                <option value="Freelance" <?php echo ($job_type == 'Freelance') ? 'selected' : ''; ?>>Freelance</option>
            </select>

            <button type="submit">Filter</button>
        </form>
    </section>

    <!-- Job Listings -->
    <section class="job-listings">
        <?php if ($result->num_rows > 0): ?>
            <?php while ($job = $result->fetch_assoc()): ?>
                <div class="job">
                    <h3><?php echo htmlspecialchars($job['title']); ?></h3>
                    <p><?php echo nl2br(htmlspecialchars($job['description'])); ?></p>
                    <p><strong>Category:</strong> <?php echo htmlspecialchars($job['category']); ?></p>
                    <p><strong>Job Type:</strong> <?php echo htmlspecialchars($job['job_type']); ?></p>
                    <p><strong>Budget:</strong> $<?php echo number_format($job['budget'], 2); ?></p>
                    <p><strong>Client:</strong> <?php echo htmlspecialchars($job['client_name']); ?></p>
                    <a href="job_details.php?id=<?php echo $job['id']; ?>" class="btn">View Details</a>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No jobs found matching your criteria.</p>
        <?php endif; ?>
    </section>
</div>

<?php include("../includes/footer.php"); ?>
