<?php
session_start(); // Start the session
include("../includes/db_connect.php"); // Database connection

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    die("Error: You must be logged in to view this page.");
}

$user_id = $_SESSION['user_id'];

// Fetch jobs posted by the logged-in user
$query = "SELECT * FROM jobs WHERE client_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Check for query errors
if (!$result) {
    die("Error fetching jobs: " . $conn->error);
}
?>

<div class="container">
    <h2>Your Posted Jobs</h2>
    <?php while ($job = $result->fetch_assoc()): ?>
        <div class="job">
            <h3><?php echo htmlspecialchars($job['title']); ?></h3>
            <p><?php echo htmlspecialchars($job['description']); ?></p>
            <p><strong>Budget:</strong> $<?php echo htmlspecialchars($job['budget']); ?></p>
            <a href="job_details.php?id=<?php echo $job['id']; ?>" class="btn">View Details</a>
        </div>
    <?php endwhile; ?>
</div>

<?php include("../includes/footer.php"); ?>
