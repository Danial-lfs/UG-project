

<?php
include("../includes/header.php");
include("../includes/db_connect.php");

if (!isset($_GET['id'])) {
    echo "Invalid job ID.";
    exit();
}

$job_id = $_GET['id'];
$query = "SELECT jobs.*, users.name AS client_name FROM jobs JOIN users ON jobs.client_id = users.id WHERE jobs.id = $job_id";
$result = $conn->query($query);

if ($result->num_rows == 0) {
    echo "Job not found.";
    exit();
}

$job = $result->fetch_assoc();
?>

<div class="container">
    <h2><?php echo $job['title']; ?></h2>
    <p><?php echo $job['description']; ?></p>
    <p><strong>Budget:</strong> $<?php echo $job['budget']; ?></p>
    <p><strong>Client:</strong> <?php echo $job['client_name']; ?></p>

    <?php if (isset($_SESSION['user_id'])): ?>
        <a href="apply_job.php?job_id=<?php echo $job['id']; ?>" class="btn">Apply for this Job</a>
    <?php else: ?>
        <p><a href="login.php">Login</a> to apply.</p>
    <?php endif; ?>
</div>

<?php include("../includes/footer.php"); ?>
