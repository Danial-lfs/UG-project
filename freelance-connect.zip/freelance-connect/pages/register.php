<?php include("../includes/header.php"); ?>

<div class="container">
    <h2>Register</h2>
    <form action="../process/register_user.php" method="post">
        <input type="text" name="name" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>

        <!-- 🔽 Role Selection -->
        <select name="role" required>
            <option value="">-- Select Role --</option>
            <option value="user">Register as User</option>
            <option value="admin">Register as Admin</option>
        </select>

        <button type="submit">Register</button>
    </form>
</div>

<?php include("../includes/footer.php"); ?>
