<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include("../includes/db_connect.php");

if (!isset($_GET['payment_id'])) {
    echo "Invalid payment.";
    exit();
}

$payment_id = $_GET['payment_id'];

// Verify client owns the job
$query = "SELECT * FROM payments WHERE id = $payment_id AND client_id = ".$_SESSION['user_id'];
$result = $conn->query($query);
$payment = $result->fetch_assoc();

if (!$payment) {
    echo "Unauthorized action.";
    exit();
}

// Release payment
$update_query = "UPDATE payments SET status = 'released' WHERE id = $payment_id";
if ($conn->query($update_query) === TRUE) {
    header("Location: dashboard.php");
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
