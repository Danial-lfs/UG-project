<?php
// No session_start() here – it's already handled in header.php
include("../includes/db_connect.php");
include("../includes/header.php");

// Debug (optional): Check if session is working
// echo "Logged in as: " . ($_SESSION['role'] ?? 'Not set');

// Check if user is admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo "<h3 style='color:red; text-align:center;'>Access denied. Admins only.</h3>";
    include("../includes/footer.php");
    exit;
}

// Function to display any table
function showTable($conn, $table) {
    $result = $conn->query("SELECT * FROM $table");
    if ($result && $result->num_rows > 0) {
        echo "<h3 style='margin-top:40px;'>Table: $table</h3>";
        echo "<table class='dashboard-table'>";
        // Print headers
        echo "<tr>";
        while ($field = $result->fetch_field()) {
            echo "<th>" . htmlspecialchars($field->name) . "</th>";
        }
        echo "</tr>";
        // Print rows
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            foreach ($row as $val) {
                echo "<td>" . htmlspecialchars($val) . "</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No data found in <strong>$table</strong>.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - Freelance Connect</title>
    <link rel="stylesheet" href="../assets/css/style.css"> <!-- Adjust path if needed -->
    <style>
        .dashboard-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 40px;
        }

        .dashboard-table th, .dashboard-table td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }

        .dashboard-table th {
            background-color: #f4f4f4;
            font-weight: bold;
        }

        .container {
            max-width: 95%;
            margin: 40px auto;
            padding: 20px;
        }

        h2 {
            text-align: center;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Admin Dashboard</h2>
    <p style="text-align: center;">Welcome Admin! Here's a view of all data:</p>

    <?php
    $tables = ['users', 'jobs', 'applications', 'payments', 'reviews', 'messages', 'notifications'];
    foreach ($tables as $table) {
        showTable($conn, $table);
    }
    ?>
</div>

<?php include("../includes/footer.php"); ?>
</body>
</html>
