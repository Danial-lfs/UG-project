<?php
session_start();
include("../includes/db_connect.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
    $password = trim($_POST['password']);

    if (empty($email) || empty($password)) {
        die("Email and password are required.");
    }

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    if (!$stmt) {
        die("Database error: " . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows === 1) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['name'] = $user['name'];

            // ✅ Redirect based on role
            if ($user['role'] === 'admin') {
                header("Location: ../process/admin_dashboard.php");
            } else {
                header("Location: ../pages/post_job.php");
            }
            exit();
        } else {
            die("Invalid password.");
        }
    } else {
        die("User not found with that email.");
    }
} else {
    die("Invalid request method.");
}
?>
